import Order from "../models/Orders.js"
import Ticket from "../models/Ticket.js"
import { Op } from "sequelize"

// CREA UN ORDINE
export const createOrder = async (req, res) => {
    try {
        const { ticketId } = req.body
        const userId = req.user.userId

        if (!ticketId) return res.status(400).json({ error: "ticketId è obbligatorio" })

        const ticket = await Ticket.findByPk(ticketId)
        if (!ticket) return res.status(404).json({ error: "Biglietto non trovato" })
        if (ticket.status !== "disponibile") return res.status(400).json({ error: "Biglietto non disponibile" })

        const expiresAt = new Date(Date.now() + 15 * 60 * 1000) //scade fra 15 minuti

        await ticket.update({ status: "impegnato" })

        const order = await Order.create({
            userId,
            ticketId,
            status: "impegnato",
            expiresAt
        })

        res.status(201).json({
            orderId: order.id,
            ticketId: ticket.id,
            expiresAt
        })
    } catch (error) {
        console.error("Errore durante la creazione dell'ordine:", error)
        res.status(500).json({ error: "Errore interno del server" })
    }
}

// ORDINI DELL'UTENTE
export const getUserOrders = async (req, res) => {
    try {
        const userId = req.user.userId
        const nowMinus2Min = new Date(Date.now() - 2 * 60 * 1000)

        const orders = await Order.findAll({
            where: {
                userId,
                [Op.or]: [{ status: { [Op.not]: "impegnato" } }, { status: "impegnato", expiresAt: { [Op.gte]: nowMinus2Min } }]
            },
            include: [
                {
                    model: Ticket,
                    as: "Ticket",
                    attributes: ["id", "title", "price", "status", "eventDate"]
                }
            ],
            order: [["createdAt", "DESC"]]
        })

        res.json(orders)
    } catch (error) {
        console.error("Errore nel recupero degli ordini:", error)
        res.status(500).json({ error: "Errore interno del server" })
    }
}

// ANNULLA ORDINE
export const cancelOrder = async (req, res) => {
    try {
        const orderId = req.params.id
        const userId = req.user.userId

        const order = await Order.findByPk(orderId)
        if (!order) return res.status(404).json({ error: "Ordine non trovato" })
        if (order.userId !== userId) return res.status(403).json({ error: "Accesso negato all'ordine" })
        if (order.status !== "impegnato") return res.status(400).json({ error: "Solo ordini 'impegnato' possono essere annullati" })

        const ticket = await Ticket.findByPk(order.ticketId)
        if (ticket) await ticket.update({ status: "disponibile" })

        await order.destroy()
        res.json({ message: "Ordine annullato e biglietto disponibile" })
    } catch (error) {
        console.error("Errore nell'annullamento ordine:", error)
        res.status(500).json({ error: "Errore server" })
    }
}

// COMPLETA ORDINE
export const completeOrder = async (req, res) => {
    try {
        const { id } = req.params
        const userId = req.user.userId

        const order = await Order.findOne({
            where: { id, userId },
            include: [
                {
                    model: Ticket,
                    as: "Ticket"
                }
            ]
        })

        if (!order) return res.status(404).json({ error: "Ordine non trovato" })
        if (order.status !== "impegnato") return res.status(400).json({ error: "Ordine non disponibile per completamento" })
        if (new Date(order.expiresAt) < new Date()) return res.status(400).json({ error: "Ordine scaduto" })

        await order.update({ status: "acquistato" })
        await order.Ticket.update({ status: "acquistato" })

        res.status(200).json({
            message: "Ordine completato con successo",
            orderId: order.id,
            ticket: {
                title: order.Ticket.title,
                price: order.Ticket.price
            }
        })
    } catch (error) {
        console.error("Errore nel completamento ordine:", error)
        res.status(500).json({ error: "Errore interno del server" })
    }
}
